# Ping Pong Retro - Outline

### Welcome!

Hello, my name is Moses (a beginner Python coder), and I decided to choose YOU because of your repls featured Pong!!! So I decided to make a bit of a throwback game referring to the original 1972 game "Pong" by Atari. I really hope you can collaborate with me. We might also make a glowy version, but that is a thought in consideration. Don't worry about the creating process; some of that is done already by me (although it may contain mistakes).

### Roles

As I always do on Discord, I always assign roles to people. Here's the roles:

@marcracho (background, in-game text, beta tester)

@SixBeeps (effects, start page, editing, HTML and CSS programmer, alpha tester) 