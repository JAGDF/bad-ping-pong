# Imports
from freegames import vector
from turtle import *
from random import *

# Variables
state = [0, 0]
ball = vector(0, 0)
aim = vector(0, 0)

# Function def
def draw():
	clear()

	paddle(-200, state[0], 10, 50)
	paddle(190, state[1], 10, 50)

	ball.move(aim)
	up()
	goto(ball.x, ball.y)
	dot(10)

	if ball.y > 200 or ball.y < -200:
		aim.y = -aim.y

	if ball.x < -185:
		low = state[0]
		high = state[0] + 50
		if low <= ball.y <= high:
			aim.x = -aim.x
		else:
			return None

	if ball.x > 185:
		low = state[1]
		high = state[1] + 50
		if low <= ball.y <= high:
			aim.x = -aim.x
		else:
			return None

	ontimer(draw, 20)

def paddle(x, y, width, height): 
	up()
	goto(x, y)
	down()

	begin_fill()
	for num in range(2):
		forward(width)
		left(90)
		forward(height)
		left(90)
	end_fill()

def move(player, change):
	state[player] += change

def aim_ball():
	aim.x = randint(1, 3) * choice([1, -1])
	aim.y = randint(1, 3) * choice([1, -1])

# Function Calls
setup(420, 420)
hideturtle()
tracer(False)

listen()
onkey(lambda: move(0, 20), 'w')
onkey(lambda: move(0, -20), 's')
onkey(lambda: move(1, 20), 'Up')
onkey(lambda: move(1, -20), 'Down')
onkey(lambda: aim_ball(), 't')

draw()

bgcolor("Black")
color("White")